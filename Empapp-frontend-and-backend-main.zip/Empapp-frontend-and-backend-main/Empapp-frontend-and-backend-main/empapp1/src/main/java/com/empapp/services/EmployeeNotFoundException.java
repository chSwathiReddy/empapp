package com.empapp.services;

public class EmployeeNotFoundException extends RuntimeException{

	private static final long serialVersionUID = 1125934271375428316L;

}