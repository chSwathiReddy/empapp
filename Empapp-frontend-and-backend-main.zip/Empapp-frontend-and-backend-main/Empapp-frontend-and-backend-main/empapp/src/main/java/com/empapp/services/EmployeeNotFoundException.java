package com.empapp.services;

public class EmployeeNotFoundException extends RuntimeException{
}